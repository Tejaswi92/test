import * as React from "react";
import { useMsal } from "@azure/msal-react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import { Avatar, Tab, Tabs } from "@mui/material";
import { StyledBox, styles, TestAutomation, VerticalDivider } from "./Styles";
import { useNavigate } from "react-router-dom";

export default function Navbar({ children }) {
    const { accounts } = useMsal();
    const account = accounts[0];
    const [value, setValue] = React.useState("one");
    const [anchorEl, setAnchorEl] = React.useState(null);
   
    const userName = account ? account.name : "";
    const userEmail = account ? account.username : "";
    const userId = account ? account?.idTokenClaims?.uid: "";
    const navigate = useNavigate();

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    const redirectToDocument = () => {  
        navigate("/documentation");
    };

    const redirectToHome = () => {  
        navigate("/");
    };

    return (
        <>
            <AppBar sx={styles.appBarStyle}>
                <Toolbar disableGutters>
                    <>
                        <Typography variant="h6"
                            noWrap
                            component="a"
                            href="/" sx={styles.typography1}>
                            <img src="/lilly-logo.png" alt="Logo" style={styles.logo} />
                        </Typography>
                        <StyledBox>
                            <TestAutomation>DTS</TestAutomation>
                        </StyledBox>
                        <VerticalDivider orientation="vertical" variant="middle" />

                        <Tabs
                            value={value}
                            onChange={handleChange}
                            textColor="inherit"
                            indicatorColor="primary"
                            aria-label="secondary tabs example"
                            sx={styles.tabStyle}
                        >
                            <Tab value="one" label="Dashboard" sx={styles.labelStyle} onClick={redirectToHome}/>
                            <Tab value="two" label="Documentation" sx={styles.labelStyle} onClick={redirectToDocument} />
                            <Tab value="three" label="Settings" sx={styles.labelStyle} onClick={redirectToHome}/>
                        </Tabs>
                    </>
                    <Box sx={{ flexGrow: 1 }} />
                    <>
                    {account && (
                        <IconButton
                            size="small"
                            color="inherit"
                            disableRipple
                            sx={styles.iconButtonHoverStyle}
                            onClick={handleClick}
                        >
                            <Avatar sx={styles.userProfileStyle}>{userName[0]}</Avatar>
                        </IconButton>
                     )}
                        <Menu
                            open={Boolean(anchorEl)}
                            anchorEl={anchorEl}
                            onClose={handleClose}
                            anchorOrigin={{
                                vertical: 'bottom',
                                horizontal: 'right',
                            }}
                            transformOrigin={{
                                vertical: 'top',
                                horizontal: 'right',
                            }}
                        >
                             <MenuItem>
                                {userId}
                            </MenuItem>
                            <MenuItem>
                                {userName}
                            </MenuItem>
                            <MenuItem>
                                {userEmail}
                            </MenuItem>
                        </Menu>
                    </>
                </Toolbar>
            </AppBar>

            <Box component={'main'} sx={{ marginTop: '6rem' }}>
                {children}
            </Box>
        </>
    );
}