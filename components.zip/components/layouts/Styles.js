import { Box, Divider, styled, Typography } from "@mui/material";

export const styles = {
    toolbarStyle: { display: "flex", justifyContent: "space-between" },

    typography1: {
        mr: 2,
        display: { xs: "none", md: "flex" },
    },
    logo: { fontSize: "4rem", width: "1em", height: ".5em" },
    tabBoxStyle: {
        flexGrow: 1,
        display: "flex",
        justifyContent: "center",
    },   
    appBarStyle: { background: "#fff", padding: "0 1rem 0 1rem" },
    tabBoxStyle: {
        flexGrow: 1,
        display: "flex",
        justifyContent: "center",
    },
    tabStyle: {
        color: "black",
        "& .MuiTabs-indicator": { backgroundColor: "red" },
    },

    labelStyle: { textTransform: "none", fontSize: "1rem" },
    
    tabIconsStyle: { display: { xs: "none", md: "flex" } },

    iconButtonHoverStyle: {
        "&:hover": {
            backgroundColor: "transparent",
        },
        alignItems : "end",
    },

    userProfileStyle: {
        bgcolor: "#D52B1E",
        color: "#FFFFFF",
        textTransform: "capitalize",
    },

    logoStyle: { height: "40px" }
};

export const TestAutomation = styled(Typography)(({ theme }) => ({
    fontWeight: 700,
    color: "white",
    position: "relative",
    zIndex: 1,
}));

export const StyledBox = styled(Box)({
    backgroundImage: "linear-gradient(135deg, #CF252F 0%, #B80D83 100%)",
    minWidth: 75,
    padding: "4px",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
    borderRadius: '0 16px 0 16px'
});

export const VerticalDivider = styled(Divider)({
    alignSelf: "center",
    height: "20px",
    marginLeft: "20px",
    marginRight: "20px",
});