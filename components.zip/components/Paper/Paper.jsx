import React from "react";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";

// A reusable Paper component styled with Material-UI, designed for consistent UI elements.
const ReusablePaper = ({ onClick, icon: Icon, title, sx = {}, children }) => {
    return (
        <Paper
            elevation={6}
            onClick={onClick}
            sx={{
                borderRadius: "20px",
                padding: "20px",
                width: "100px",
                height: "auto",
                maxWidth: "100%",
                boxShadow: "0 8px 16px rgba(0, 0, 0, 0.1), 0 4px 12px rgba(0, 0, 0, 0.1)",
                backgroundColor: "#D52B1E",
                color: "white",
                textAlign: "center",
                cursor: "pointer",
                ...sx,
            }}
        >
            {Icon && <Icon sx={{ marginBottom: "10px" }} />}
            {title && (
                <Typography variant="h6" sx={{ fontWeight: "bold" }}>
                    {title}
                </Typography>
            )}
            {children}
        </Paper>
    );
};

export default ReusablePaper;