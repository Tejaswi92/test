import React from "react";
import Alert from "@mui/material/Alert";
import Snackbar from "@mui/material/Snackbar";

// ReusableSnackbar is a reusable component for displaying a snackbar notification.
const ReusableSnackbar = ({ open, message, severity, onClose, autoHideDuration = 6000, marginBottom = '80px' }) => {
    return (
        <Snackbar
            open={open}
            autoHideDuration={autoHideDuration}
            onClose={onClose}
            anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
            sx={{ marginBottom: marginBottom }}
        >
            <Alert onClose={onClose} severity={severity} sx={{ width: "100%" }}>
                {message}
            </Alert>
        </Snackbar>
    );
};

export default ReusableSnackbar;